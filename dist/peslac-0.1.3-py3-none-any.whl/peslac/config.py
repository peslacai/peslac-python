BASE_URL = "https://api.peslac.com/api/v1"
